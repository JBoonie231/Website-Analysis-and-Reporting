#ifndef CREATEUSER_H
#define CREATEUSER_H

#include <QMainWindow>
#include "login.h"

namespace Ui {
class CreateUser;
}

class LogIn;

class CreateUser : public QMainWindow
{
    Q_OBJECT

public:
    explicit CreateUser(QWidget *parent = 0);
    ~CreateUser();

private slots:
    void on_goBack_clicked();

private:
    Ui::CreateUser *ui;
    LogIn *my_login;
};

#endif // CREATEUSER_H

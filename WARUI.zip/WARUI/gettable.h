#ifndef GETTABLE_H
#define GETTABLE_H

#include <QMainWindow>

namespace Ui {
class gettable;
}

class gettable : public QMainWindow
{
    Q_OBJECT

public:
    explicit gettable(QWidget *parent = 0);
    ~gettable();

private:
    Ui::gettable *ui;
};

#endif // GETTABLE_H

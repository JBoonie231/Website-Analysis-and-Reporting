#include "gettable.h"
#include "ui_gettable.h"

gettable::gettable(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::gettable)
{
    ui->setupUi(this);
}

gettable::~gettable()
{
    delete ui;
}

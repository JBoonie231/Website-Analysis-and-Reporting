#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>
#include "CreateUser.h"
#include "query.h"

namespace Ui {
class LogIn;
}

class CreateUser;

class LogIn : public QMainWindow
{
    Q_OBJECT

public:
   explicit LogIn(QWidget *parent = 0);
    ~LogIn();
    void readingFromTextFile();

private slots:
    void on_CreateUser_clicked();
    void on_LogIn_2_clicked();

private:
    Ui::LogIn *ui;
    CreateUser *signUp;
    Query *search;
};


#endif // LOGIN_H

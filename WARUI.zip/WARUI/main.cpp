#include "login.h"
#include <QApplication>
#include "createuser.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   LogIn w;
   w.show();
    return a.exec();
}

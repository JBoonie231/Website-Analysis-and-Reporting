#ifndef QUERY_H
#define QUERY_H

#include <QMainWindow>

namespace Ui {
class Query;
}

class Query : public QMainWindow
{
    Q_OBJECT

public:
    explicit Query(QWidget *parent = 0);
    ~Query();

private:
    Ui::Query *ui;
};

#endif // QUERY_H

#include "login.h"
#include "ui_login.h"
#include <QDebug>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>

//LogIn::LogIn(CreateUser *main_window):QMainWindow(main_window),
LogIn::LogIn(QWidget *parent) :
   QMainWindow(parent),
    ui(new Ui::LogIn)
{
    ui->setupUi(this);
}

LogIn::~LogIn()
{
    delete ui;
}

/*
void LogIn::readingFromTextFile()
{
    QString path = QFileInfo("SignIn.txt").absoluteFilePath();
    qDebug()<<path;
    QFile inputFile(path);
    if(!inputFile.open(QIODevice::ReadOnly|QIODevice::Text))
        qDebug()<<"ERROR: COULD NOT OPEN FILE.";
    if(inputFile.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        QTextStream in(&inputFile);
        QString line = in.readLine();
        while (!in.atEnd())
        {
            line = in.readLine();
            qDebug()<<line;
        }
       inputFile.close();
    }
}
*/

static void process_line(const QByteArray &)
{
}

static void process_line(const QString &)
{
}

void LogIn::readingFromTextFile()
{
   // QString path = QFileInfo("SignIn.txt").absoluteFilePath();
    QFile file("/Users/sara_adra/Desktop/cs441/Website-Analysis-and-Reporting/WARUI/SignIn.txt");
    //qDebug()<<path;
            if(!file.open(QIODevice::ReadOnly|QIODevice::Text))
            {
                qDebug()<<"ERROR CAN NOT OPEN FILE";
                return;
            }
            while(!file.atEnd())
            {
                QByteArray line = file.readLine();
                process_line(line);
                qDebug()<<line;
            }
}


void LogIn::on_CreateUser_clicked()
{
    signUp = new CreateUser(this);
    signUp->setGeometry(geometry());
    this-> hide();
    signUp-> show();
}

void LogIn::on_LogIn_2_clicked()
{
    readingFromTextFile();
    search = new Query(this);
    search->setGeometry(geometry());
    this-> hide();
    search-> show();
}

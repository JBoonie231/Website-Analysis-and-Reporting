#include "createuser.h"
#include "ui_createuser.h"

CreateUser::CreateUser(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::CreateUser)
{
    setFixedSize(400, 350);
    ui->setupUi(this);
}

CreateUser::~CreateUser()
{
    delete ui;
}

void CreateUser::on_goBack_clicked()
{
    my_login = new LogIn(this);
    my_login->setGeometry(geometry());
    this-> hide();
    my_login-> show();
}
